#include "lab2.h"
//Variables

matlab_var_t vars[6] = {
    [0].n = 'a',
    [0].v = 0,
    [1].n = 'b',
    [1].v = 0,
    [2].n = 'c',
    [2].v = 0,
    [3].n = 'r',
    [3].v = 0,
    [4].n = 'x',
    [4].v = 0,
    [5].n = 'y',
    [5].v = 0
};
// Arrays
matlab_arr_t arrs[6] = {
        [0].n = 'A',
        [0].v = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        [1].n = 'B',
        [1].v = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        [2].n = 'C',
        [2].v = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        [3].n = 'R',
        [3].v = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        [4].n = 'X',
        [4].v = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
        [5].n = 'Y',
        [5].v = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
};


int main(int argc, char *argv[]){
    while(argc==1){
	char buffer[100];
	fgets(buffer, sizeof(buffer), stdin); /*Reads line*/
	processLine(buffer);
    }
}

//Parsing the input from the user


int parseString(const char *line, char *string1, char *string2,char *string3, char *numbers, char *op){
    int EQS=0, divider=0;
    
    while( *line != ' ' && *line != '=' && *line != '\n'){
	*string1=*line;
	++line;
	++string1;
    }
    if(*line==' ' || *line == '='){
	if(*line == '='){
	    EQS = 1;
	}
	++line;    
	while(*line != '\n'){
	    if(*line == ' '){
		divider=1;
		++line;
	    }
	    if(*line == '+' || *line == '-' || *line == '*' || *line == '/'){
		*op=*line;
		++op;
		++line;
		*op='\0';
		divider=1; //Splits the strings so that the next char after this is put into another string.
	    }
	    else if(isdigit(*line)){
		while(*line != '\n'){
		    *numbers=*line;
		    ++numbers;
		    ++line;
		}
		break;
	    }
	    else if(divider == 0){
		*string2=*line;
		++string2;
		++line;
	    }
	    else{
		*string3=*line;
		++string3;
		++line;
	    }
	}
    }
    else{	    
	*string1='\0';
	*string2='\0';
	*string3='\0';
	*numbers='\0';	
	return(EQS);
    }
*string1='\0';
*string2='\0';
*string3='\0';
*numbers='\0';	
return(EQS);
}


int processLine(const char *line){
    //int parseString(const char *line, char *string1, char *string2, char *string3, char *numbers, char *op);
    int EQS, i = 0, j= 0;
    char str1[20], str2[20], str3[20], num[20], operator[2];
    double start = 0.0, end = 0.0;
    char *ptr;

    EQS = parseString(line, str1, str2, str3, num, operator);

    char *input[3] = {
	str1,
	str2,
	str3,
    };
    //Makes any numbers given as input into double (One or 2 doubles possible)
    if(*num !='\0'){
	char tempstr[20];
	while(num[i] != ' ' && num[i] != '\0'){
	    tempstr[i] = num[i];
	    ++i;
	}
	start = strtod(tempstr, &ptr);
	++i;
	while(num[i] != '\0'){
	    tempstr[j]=num[i];
	    ++j;
	    ++i;
	}
	end = strtod(tempstr, &ptr);
    }
    // Determining actions based on the input of the user
    // --------------------------------------------------

    if(strcmp(input[0],"exit") == 0){
	printf("Exiting program");
	exit(0);
    }
    else if(strcmp(input[0],"help") == 0){
	printf("Available commands:\n");
    }
    else if(strcmp(input[0],"set") == 0){
	set(*input[1] , start);    
    }
    else if(strcmp(input[0],"clear") == 0){
	clear(*input[1]);
    }
    else if(strcmp(input[0],"show") == 0){
	show(*input[1]);
    }
    else if(strcmp(input[0],"array") == 0){
	array(*input[1], start, end);
    }
    else if(EQS == 1){
	calc(*input[0],*input[1],*input[2],*operator);
    }
    else if(strcmp(input[0],"show_vars") == 0){
	show_vars();
    }
    else if(strcmp(input[0],"showCSV") == 0){
	showCSV(input[1]);
    }
    else if(strcmp(input[0],"importCSV") == 0){
	importCSV(*input[1], input[2]);
    }
    else if(strcmp(input[0],"exportCSV") == 0){
	exportCSV(*input[1], input[2]);
    }
    else if(strcmp(input[0], "exportMAT") == 0){
	exportMAT(*input[1], input[2]);	
    }
    else if(strcmp(input[0], "sin") == 0){
	sinArr(*input[1], *input[2]);
    }
    else if(strcmp(input[0], "debounce") == 0){
	debounce(*input[1], *input[2]);
    }
    else if(strcmp(input[0], "event") == 0){
	event(*input[1], *input[2]);
    }
    else{
	printf("Unknown command\n");
    }
return(0);
}


