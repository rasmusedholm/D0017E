#include "lab2_funcs.h"
#include "lab2.h"

//Functions for finding a hard coded variable or arrays and creating a pointer to it.

matlab_arr_t *find_arr(char name){
    for(int i = 0;i<6;i++){
	if(name ==arrs[i].n){
	    return &arrs[i];
	}
    }
    return NULL;
}

matlab_var_t *find_var(char name){
    for(int i = 0;i<6;i++){
	if(name ==vars[i].n){
	    return &vars[i];
	}
    }
    return NULL;
}


// FUNCTIONS OF THE MINI-MATLAB BELOW

void printHelp() {

}

int set(char name, double v){
    if(name == 'A' || name == 'B' || name == 'C' || name == 'R' || name == 'X' || name == 'Y'){
	matlab_arr_t *arrptr = find_arr(name);
	for(int i = 0; i<ARRAY_LEN;i++){
	    arrptr->v[i] = v;
	}
    }
    else{
	matlab_var_t *varptr = find_var(name);
	varptr->v = v;
    }
return(0);
}

int clear(char name){
    if(name == 'A' || name == 'B' || name == 'C' || name == 'R' || name == 'X' || name == 'Y'){
	matlab_arr_t *arrptr = find_arr(name);
	for(int i = 0; i<ARRAY_LEN;i++){
	    arrptr->v[i] = 0.00;
	}
    }
    else{
	matlab_var_t *varptr = find_var(name);
	varptr->v = 0.00;
    }
return(0);
}

int show(char name){
    if(name == 'A' || name == 'B' || name == 'C' || name == 'R' || name == 'X' || name == 'Y'){
	matlab_arr_t *arrptr = find_arr(name);
	printf("%c = \n",arrptr->n);
	for(int i = 0; i<ARRAY_LEN; i++){
	    printf("%.3g \n",arrptr->v[i]);
	}
    }
    else{
	matlab_var_t *varptr = find_var(name);
	printf("%c = %.3g \n",varptr->n, varptr->v);
    }
return(0);
}

int array(char name, double start, double end){
    matlab_arr_t *arrptr = find_arr(name);
    double step = (end-start)/ARRAY_LEN;
    for(int i = 0; i<ARRAY_LEN; i++){
	arrptr->v[i] = start + i*step;
    }
return(0);
}

int calc(char r, char x, char y, char op){
    if(r == 'A' || r == 'B' || r == 'C' || r == 'R' || r == 'X' || r == 'Y'){
	matlab_arr_t *arrptr1 = find_arr(r);
	matlab_arr_t *arrptr2 = find_arr(x);
	matlab_arr_t *arrptr3 = find_arr(y);
	if(op == '+'){
	    for(int i = 0; i<ARRAY_LEN; i++){
		arrptr1->v[i] = arrptr2->v[i] + arrptr3->v[i];
	    }
	}
	else if(op == '-'){
	     for(int i = 0; i<ARRAY_LEN; i++){
		arrptr1->v[i] = arrptr2->v[i] - arrptr3->v[i];
	    }
	}
	else{
	    printf("Non permitted operator for arrays");
	}
    }
    else{
	matlab_var_t *varptr1 = find_var(r);
	matlab_var_t *varptr2 = find_var(x);
	matlab_var_t *varptr3 = find_var(y);
	if(op == '+'){
	    varptr1->v = varptr2->v + varptr3->v;
	}
	else if(op == '-'){
	    varptr1->v = varptr2->v - varptr3->v;
	}
	else if(op == '*'){
	    varptr1->v = varptr2->v * varptr3->v;
	}
	else if(op == '/'){
	    varptr1->v = varptr2->v / varptr3->v;
	}
    }
return(0);
}

void show_vars(void){
    for(int i = 0; i<6;i++){
	printf("%c = %g\n", vars[i].n, vars[i].v);
    }
}

int showCSV(const char *filename){
    FILE *fp=fopen(filename,"r");
    char buf[50];
    while (fgets(buf, 50, fp)) {
        printf("%s\n", buf);
    }
    fclose(fp);
return(0);
}

int importCSV(char var, const char *filename){
    matlab_arr_t *arrptr = find_arr(var);
    int i = 0;
    char buffer[50], *ptr;
    FILE *fp=fopen(filename,"r");
    while(fgets(buffer, sizeof(buffer), fp) != NULL){
	arrptr->v[i] = strtod(buffer, &ptr);
	i++;
    }
    fclose(fp);
return(0);
}

int exportCSV(char var, const char *filename){
    char temp[50];
    matlab_arr_t *arrptr = find_arr(var);
    FILE *fp = fopen(filename,"w");
    for(int i = 0; i<ARRAY_LEN; i++){
	sprintf(temp,"%lf",arrptr->v[i]);
	fputs(temp,fp);
	fputc('\n',fp);
    }
    fclose(fp);
return(0);
}

int exportMAT(char var, const char *filename){
    matlab_arr_t *arrptr = find_arr(var);
    FILE *fp = fopen(filename, "wb");
    Fmatrix h;

    h.type = 0;
    h.mrows = ARRAY_LEN;
    h.ncols = 1;
    h.imagf = 0;
    h.namelen = 1; 
    
    fwrite(&h, sizeof(Fmatrix), 1, fp);
    fwrite(&var,sizeof(char), h.namelen, fp);
    fwrite(arrptr->v, sizeof(double), ARRAY_LEN, fp);
    fclose(fp);
return(0);
}

int sinArr(char var1, char var2){
    matlab_arr_t *arrptr1 = find_arr(var1);
    matlab_arr_t *arrptr2 = find_arr(var2);
    for(int i = 0 ; i<ARRAY_LEN; i++){
	arrptr1->v[i]=sin(arrptr2->v[i]);
    }
return(0);
}

int debounce(char R, char I){
    matlab_arr_t *arrptr1 = find_arr(R);
    matlab_arr_t *arrptr2 = find_arr(I);
    for(int i = 0; i<ARRAY_LEN; i++){
	for(int j = 0; j<10; j++){
	    if(arrptr2->v[i+j] > 3){
		arrptr1->v[i] = 3.3;
		break;
	    }
	}
	if(arrptr1->v[i] != 3.3){
	    arrptr1->v[i] = 0.0;
		for(int k = i ;k<ARRAY_LEN; k++){
		    arrptr1->v[k] = 0.0;
		}
	    break;
	} 
    }
return(0);
}

int event(char R, char I){
    matlab_arr_t *arrptr1 = find_arr(R);
    matlab_arr_t *arrptr2 = find_arr(I);
    int cont = 0, check = 0;
    for(int i = 0; i<ARRAY_LEN; i++){
	if(check == 0){
	    for(int j = 0; j<10; j++){
		if(arrptr2->v[i+j] >0.5){
		    cont++;
		}
	    }
	}
	if(cont >= 10){
	    arrptr1->v[i] = arrptr2->v[i];
	    check = 1;
	}
	else{
	    arrptr1->v[i] = 0.00;
	}
	if(arrptr1->v[i] < 0.5){
	    check = 0;
	    cont = 0;
	}
    }
return(0);
}

