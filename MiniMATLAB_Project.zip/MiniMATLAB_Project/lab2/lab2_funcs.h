#ifndef __LAB2_FUNCS_H__
#define __LAB2_FUNCS_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
/*
//Header for .MAT files(?)
typedef struct{
	uint32_t type;
	uint32_t mrows;
	uint32_t ncols;
	uint32_t imagf;
	uint32_t namelen;
} Fmatrix;
*/
// add all other functions below
int parseString(const char *line, char *string1, char *string2, char *string3, char *numbers, char *op);
int clear(char name);
int calc(char r, char x, char y, char op);


#endif /* __LAB2_FUNCS_H__ */

